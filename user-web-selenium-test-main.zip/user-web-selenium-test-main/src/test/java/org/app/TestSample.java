package org.app;

 
import org.junit.Assert;
import org.junit.Test;

 

 

public class TestSample {
  
	 @Test
	 public void testSample(){
		  Assert.assertEquals(true, false);
	 }
}
