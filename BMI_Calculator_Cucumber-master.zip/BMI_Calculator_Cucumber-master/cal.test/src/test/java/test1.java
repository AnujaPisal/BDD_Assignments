import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


public class test1
{
    WebDriver driver;

    @BeforeTest
    void initialize()
    {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.get("https://www.calculator.net/bmi-calculator.html");
        driver.manage().window().maximize();
    }

    @AfterTest
    public void Close_driver()
    {
        driver.close();
    }


    String calculate(String n, String m, String o)
    {
        WebElement button = driver.findElement(By.className("clearbtn"));
        button.click();
        driver.findElement(By.id("cage")).sendKeys(n);

        driver.findElement(By.name("cheightmeter")).sendKeys(m);
        driver.findElement(By.name("ckg")).sendKeys(o);
        driver.findElement(By.xpath("//input[@type='image']")).click();
        String  actual = driver.findElement(By.tagName("b")).getText().trim();
        return actual;

    }
    @Test(priority = 1)
    void test1()
    {
        driver.findElement(By.className("rbmark")).click();
        Assert.assertEquals(calculate("20","180","60"),"BMI = 18.5 kg/m2");
    }
    @Test(priority = 2)
    void test2()
    {
        driver.findElement(By.xpath("//tbody/tr[2]/td[2]/label[2]")).click();
        Assert.assertEquals(calculate("35","160","55"),"BMI = 21.5 kg/m2");
    }
    @Test(priority = 3)
    void test3()
    {
        driver.findElement(By.className("rbmark")).click();
        Assert.assertEquals(calculate("50","175","65"),"BMI = 21.2 kg/m2");

    }
    @Test(priority = 4)
    void test4()
    {
        driver.findElement(By.xpath("//tbody/tr[2]/td[2]/label[2]")).click();
        Assert.assertEquals(calculate("45","150","52"),"BMI = 23.1 kg/m2");
    }
}