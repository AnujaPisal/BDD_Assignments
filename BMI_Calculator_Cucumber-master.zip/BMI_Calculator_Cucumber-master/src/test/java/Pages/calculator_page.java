
package Pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class calculator_page
{
    WebDriver driver;
    WebDriverWait wait;

    public calculator_page(WebDriver driver1, WebDriverWait wait) {
        driver = driver1;
        // driver.get("https://www.calculator.net/bmi-calculator.html");
        //driver.manage().window().maximize();
        this.wait = wait;

    }

    public void enterage() throws InterruptedException {
        driver.findElement(By.xpath("//tbody/tr[1]/td[1]/img[1]")).click();
        Thread.sleep(1000);
        WebElement e1 = driver.findElement(By.id("cage"));
        Thread.sleep(1000);
        e1.sendKeys("20");
    }

    public void selectGender() {
        WebElement radio1 = driver.findElement(By.xpath("//tbody/tr[2]/td[2]/label[1]"));
        radio1.click();
    }

    public void enterheight() {
        WebElement h1= driver.findElement(By.id("cheightmeter"));
        h1.sendKeys("180");

    }

    public void enterweight() throws InterruptedException {
        WebElement we1= driver.findElement(By.id("ckg"));
        we1.sendKeys("60");
        Thread.sleep(1000);
    }

    public void clickCalculateButton() {
        WebElement cal = driver.findElement(By.xpath("//tbody/tr[1]/td[1]/input[2]"));
        cal.click();
    }

    public void getresult() {
        WebElement actual = driver.findElement(By.tagName("b"));
        String s1 = actual.getText();
        Assert.assertEquals("BMI = 18.5 kg/m2", s1);
    }


            // public String calculate(String n, String m, String o) {

            //   driver.findElement(By.id("cage")).sendKeys(n);

            // driver.findElement(By.name("cheightmeter")).sendKeys(m);
            //driver.findElement(By.name("ckg")).sendKeys(o);
            //  driver.findElement(By.xpath("//input[@type='image']")).click();
            //String actual = driver.findElement(By.tagName("b")).getText().trim();
            //return actual;

            // enternumber();
            //  enterage(n);
            // enterheight(m);
            // enterweight(o);
            //void click = calculate();
            // return getresult();
 }




