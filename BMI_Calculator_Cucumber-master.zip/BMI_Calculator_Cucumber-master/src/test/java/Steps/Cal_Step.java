package Steps;

import Pages.calculator_page;
import Utils.TestContext;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.testng.Assert;

public class Cal_Step extends TestContext
{
    calculator_page calc_page;

    @Given("I am on calculator page")
    public void iAmOnCalculatorPage() {
        calc_page = new calculator_page(driver,wait);
    }



    @And("I enter <age>  in calculator")
    public void iEnterAgeInCalculator() throws InterruptedException {
        calc_page.enterage();
    }

    @And("I select <gender> in calculator")
    public void iSelectGenderInCalculator() throws InterruptedException {
        calc_page.selectGender();
    }

    @And("I enter <height> in calculator")
    public void iEnterHeightInCalculator() {
        calc_page.enterheight();

    }

    @And("I enter <weight> in calculator")
    public void iEnterWeightInCalculator() throws InterruptedException {
        calc_page.enterweight();
    }

    @And("I press <calculate> button")
    public void iPressCalculateButton() {
        calc_page.clickCalculateButton();
    }

    @Then("I see the result is<Expected_result>")
    public void iSeeTheResultIsExpected_result() {
        calc_page.getresult();
    }



}
